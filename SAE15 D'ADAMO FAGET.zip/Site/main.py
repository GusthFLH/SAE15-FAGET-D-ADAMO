#Copyright : Faget Alexandre , Florent D'Adamo
#	25/01/2022  14:07



import requests,time
from lxml import etree 

denom_m=0
num_m=0
ocup_v=0

parkings=['FR_MTP_ANTI','FR_MTP_COME','FR_MTP_CORU','FR_MTP_EURO','FR_MTP_FOCH','FR_MTP_GAMB','FR_MTP_GARE','FR_MTP_TRIA','FR_MTP_ARCT',
'FR_MTP_PITO','FR_MTP_CIRC','FR_MTP_SABI','FR_MTP_GARC','FR_MTP_SABL','FR_MTP_MOSS','FR_STJ_SJLC','FR_MTP_MEDC','FR_MTP_OCCI','FR_CAS_VICA',
'FR_MTP_GA109','FR_MTP_GA250','FR_CAS_CDGA','FR_MTP_ARCE','FR_MTP_POLY']

i=0
f4=open("places_v.txt","w", encoding='utf8')
f2=open("places.txt","w", encoding='utf8')
f5=open("data.dat","w",encoding='utf8')
while i != 1 :
  for p in parkings:
    f1=open("temp.txt","w",encoding='utf8')
    URL=requests.get(f"https://data.montpellier3m.fr/sites/default/files/ressources/{p}.xml")
    f1.write(URL.text) 
    f1.close()
			
		
    tree = etree.parse("temp.txt") 
    for user in tree.xpath("Status"): 
      if user.text == "Open":
        for user in tree.xpath("Name"): 
          print('Nom du parking :',user.text)
          f2.write(user.text+" ")
        for user in tree.xpath("Total"): 
          print('Nombre total de places :',user.text) 
          denom=int(user.text)
          denom_m+=denom
          f2.write(user.text+" ")
        for user in tree.xpath("Free"): 
          print('Nombre de places libres :',user.text)
          num = int(user.text)
          num_m+=num
          f2.write(user.text+" ")
        prct= (num/denom)*100
        prct=round(prct,2)
        print(str(prct)+"%")
        f2.write(str(prct))
        f2.write("\n")
        print("________________________________")
      else:
      	print("Parking fermé")
  prct_m=(num_m/denom_m)*100
  prct_m=round(prct_m,2)
  f2.write('Taux max'+str(prct_m))
  print(str(prct_m)+"%")
  URL2=requests.get("https://data.montpellier3m.fr/sites/default/files/ressources/TAM_MMM_VELOMAG.xml")
  f3=open("temp2.txt","w",encoding='utf8')
  f3.write(URL2.text)
  f3.close()
  tree = etree.parse('temp2.txt')
  for user in tree.xpath("/vcs/sl/si"):
    f4.write(user.get('na')+' ')
    f4.write(user.get('fr')+' ')
    ocup_v=ocup_v+(int(user.get('to'))-(int(user.get('fr'))))
    f4.write(user.get('to')+'\n')
  occup=denom_m-num_m
  f5.write(str(occup)+' ')
  f5.write(str(ocup_v)+'\n')
  time.sleep(1)     #Reload toutes les 15 minutes
  i+=1
f2.close()
f4.close()
# cd ! ce mettre dans le bon répertoire
#set terminal png size 700,500 enhanced fname 'arial' fsize 10 butt solid ! Je met l'image en png
#set key inside bottom right
#set xlabel 'Time heure'
#set ylabel 'Pourcentage Places occupées'
#set title 'graphique parking voiture/velo'
#plot "data.dat" using 1:2 title 'Placeoccupvoiture' with linespoints, "data.dat" using 1:3 title 'Placeoccupvelo' with linespoints
#set output 'C:\Users\Utilisateur\Desktop\image.png' ! chemin pour créer mon image